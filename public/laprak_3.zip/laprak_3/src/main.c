#include <stdio.h>

int main()
{
    char nama[50];
    float sosial_media, telepon, youtube, tagihan;

    printf("Program Menghitung Tagihan Internet Rumah\n");
    printf(".........................................\n");
    
    printf("Input nama customer  : ");
    scanf("%s", nama);  // Correct usage for char array
    
    printf("Input sosial media (dalam GB): ");
    scanf("%f", &sosial_media);
    
    printf("Input telepon (dalam GB): ");
    scanf("%f", &telepon);
    
    printf("Input youtube (dalam GB): ");
    scanf("%f", &youtube);

    // Calculate total
    tagihan = sosial_media + telepon + youtube;

    // Display the result
    printf("\nTagihan anda adalah: %.2f GB\n", tagihan);

    return 0;
}
