package meilaaaaaaa;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AVLTreeVisualization extends JFrame {
    private AVLTree tree = new AVLTree();
    private JTextField inputField;
    private JPanel treePanel;
    private JTextArea resultArea;

    public AVLTreeVisualization() {
        setTitle("AVL Tree Visualization");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        inputField = new JTextField(10);
        JButton insertButton = new JButton("Insert");
        JButton deleteButton = new JButton("Delete");
        JButton findButton = new JButton("Find");
        JButton preorderButton = new JButton("Preorder");
        JButton inorderButton = new JButton("Inorder");
        JButton postorderButton = new JButton("Postorder");

        JPanel controlPanel = new JPanel();
        controlPanel.add(new JLabel("Value:"));
        controlPanel.add(inputField);
        controlPanel.add(insertButton);
        controlPanel.add(deleteButton);
        controlPanel.add(findButton);
        controlPanel.add(preorderButton);
        controlPanel.add(inorderButton);
        controlPanel.add(postorderButton);

        add(controlPanel, BorderLayout.NORTH);

        treePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                setBackground(Color.LIGHT_GRAY); // Mengubah warna latar belakang
                drawTree(g, tree.root, getWidth() / 2, 50, getWidth() / 4);
            }
        };

        add(treePanel, BorderLayout.CENTER);

        resultArea = new JTextArea(5, 20);
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        add(scrollPane, BorderLayout.SOUTH);

        insertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int value = Integer.parseInt(inputField.getText());
                    tree.root = tree.insert(tree.root, value);
                    treePanel.repaint();
                    inputField.setText("");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid integer.");
                }
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int value = Integer.parseInt(inputField.getText());
                    tree.root = tree.deleteNode(tree.root, value);
                    treePanel.repaint();
                    inputField.setText("");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid integer.");
                }
            }
        });

        findButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int value = Integer.parseInt(inputField.getText());
                    AVLTreeNode node = tree.find(tree.root, value);
                    if (node != null) {
                        JOptionPane.showMessageDialog(null, "Value " + value + " found in the tree.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Value " + value + " not found in the tree.");
                    }
                    inputField.setText("");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid integer.");
                }
            }
        });

        preorderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder sb = new StringBuilder();
                tree.preorder(tree.root, sb);
                resultArea.setText("Preorder: " + sb.toString());
            }
        });

        inorderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder sb = new StringBuilder();
                tree.inorder(tree.root, sb);
                resultArea.setText("Inorder: " + sb.toString());
            }
        });

        postorderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder sb = new StringBuilder();
                tree.postorder(tree.root, sb);
                resultArea.setText("Postorder: " + sb.toString());
            }
        });
    }

    private void drawTree(Graphics g, AVLTreeNode node, int x, int y, int gap) {
        if (node != null) {
            FontMetrics fm = g.getFontMetrics();
            int nodeWidth = Math.max(30, fm.stringWidth(String.valueOf(node.key)) + 10);
            int nodeHeight = 30;
            
            g.setColor(Color.BLUE); // Mengubah warna node
            g.drawOval(x - nodeWidth / 2, y - nodeHeight / 2, nodeWidth, nodeHeight);
            g.setColor(Color.WHITE); // Mengubah warna teks node
            g.drawString(Integer.toString(node.key), x - fm.stringWidth(String.valueOf(node.key)) / 2, y + fm.getHeight() / 4);
            
            if (node.left != null) {
                g.setColor(Color.RED); // Mengubah warna garis kiri
                g.drawLine(x, y + nodeHeight / 2, x - gap + nodeWidth / 2, y + 50 - nodeHeight / 2);
                drawTree(g, node.left, x - gap, y + 50, gap / 2);
            }
            if (node.right != null) {
                g.setColor(Color.GREEN); // Mengubah warna garis kanan
                g.drawLine(x, y + nodeHeight / 2, x + gap - nodeWidth / 2, y + 50 - nodeHeight / 2);
                drawTree(g, node.right, x + gap, y + 50, gap / 2);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AVLTreeVisualization().setVisible(true);
            }
        });
    }
}
