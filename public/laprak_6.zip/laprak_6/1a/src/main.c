#include <stdio.h>
#include <math.h>

int main()
{
    int x;
    printf("perulangan pangkat 2 dari 1-10:\n");
    for (x = 1; x <= 10; x++) {
        printf("%d ^ 2 = %d\n", x, x * x);
    }
    return 0;
}