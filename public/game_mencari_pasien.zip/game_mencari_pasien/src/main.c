#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct data
{
   int perawatX, perawatY, pasienX, pasienY;
} Data;

void saveGame()
{
   FILE *fp;
   fp = fopen("gameperawatpasien.bin", "w");
   fprintf(fp, "%d %d %d %d", Data.perawatX, Data.perawatY, Data.pasienX, Data.pasienY);
   fclose(fp);
   printf("GAME SAVED SUCCESSFULLY!\n");
   getchar();
}

void loadGame()
{
   FILE *fp;
   fp = fopen("gameperawatpasien.bin", "rb");
   fscanf(fp, "%d %d %d %d", &Data.perawatX, &Data.perawatY, &Data.pasienX, &Data.pasienY);
   Data.perawatX--;
   Data.perawatY--;
   Data.pasienX--;
   Data.pasienY--;
   fclose(fp);
   printf("GAME LOADED SUCCESSFULLY!\n");
}

int menu()
{
   printf("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000\n");
   printf("----------------------------------GAME PERAWAT MENCARI PASIEN------------------------------------------------\n");
   printf("---------------------KELOMPOK 4 DASAR PEMROGRAMAN TEKNOLOGI INFORMASI UNISA----------------------------------\n");
   printf("0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000\n");
   printf("000000000000   ###   ###   0000000000000000000000000000000000000000    ###   ###   00000000000000000000000000\n");
   printf("000000000000 #    # #    # 000000000000000000000000000000000000000000 #   # #   # 000000000000000000000000000\n");
   printf("00000000000 #      #      # 0000000000000000000000000000000000000000 #     #     # 00000000000000000000000000\n");
   printf("000000000000 #           # 00000000000000000000000000000000000000000 #           # 00000000000000000000000000\n");
   printf("0000000000000 #         # 0000000000000000000000000000000000000000000 #         # 000000000000000000000000000\n");
   printf("00000000000000 #       # 000000000000000000000000000000000000000000000 #       # 0000000000000000000000000000\n");
   printf("000000000000000 #     # 00000000000000000000000000000000000000000000000 #     # 00000000000000000000000000000\n");
   printf("0000000000000000 #   # 0000000000000000000000000000000000000000000000000 #   # 000000000000000000000000000000\n");
   printf("000000000000000000 # 00000000000000000000000000000000000000000000000000000 # 00000000000000000000000000000000\n");
   printf("000000000000000000000000000000000000000000   ###   ###   0000000000000000000000000000000000000000000000000000\n");
   printf("000000000000000000000000000000000000000000 #    # #   # 00000000000000000000000000000000000000000000000000000\n");
   printf("00000000000000000000000000000000000000000 #      #     # 0000000000000000000000000000000000000000000000000000\n");
   printf("000000000000000000000000000000000000000000 #          # 00000000000000000000000000000000000000000000000000000\n");
   printf("0000000000000000000000000000000000000000000 #        # 000000000000000000000000000000000000000000000000000000\n");
   printf("00000000000000000000000000000000000000000000 #      # 0000000000000000000000000000000000000000000000000000000\n");
   printf("000000000000000000000000000000000000000000000 #    # 00000000000000000000000000000000000000000000000000000000\n");
   printf("0000000000000000000000000000000000000000000000 #  # 000000000000000000000000000000000000000000000000000000000\n");
   printf("00000000000000000000000000000000000000000000000 #  0000000000000000000000000000000000000000000000000000000000\n");
   printf("\t|=================|  GAME  |==================|\n");
   printf("\t|\tSilahkan pilih menu                   |\n");
   printf("\t|\t1. Mulai Permainan                    |\n");
   printf("\t|\t2. Aturan Permainan                   |\n");
   printf("\t|\t3. Masuk kembali                      |\n");
   printf("\t|\t4. keluar                             |\n");
   printf("\t|=============================================|\n");
   printf("\t|\tPilih menu diatas:                    |\n");
   printf("\t|=============================================|\n");
   int pilih;
   scanf("%d", &pilih);
   if (pilih != 1 && pilih != 2 && pilih != 3 && pilih != 4)
   {
      return menu();
   }
   else
   {
      return pilih;
   }
}

char keluar()
{
   printf("\t|=============================================|\n");
   printf("\t| Apakah anda yakin untuk keluar?(y/n)        |\n");
   printf("\t|=============================================|\n");
   char pilih;
   scanf("\n%c", &pilih);
   if (pilih != 'y' && pilih != 'n')
   {
      return keluar();
   }
   else
   {
      return pilih;
   }
}

int MenuGame()
{
   printf("\t|=========== | ATURAN PERMAINAN | ============|\n");
   printf("\t|  w untuk bergerak ke atas                   |\n");
   printf("\t|  d untuk bergerak ke kanan                  |\n");
   printf("\t|  s untuk bergerak ke bawah                  |\n");
   printf("\t|  a untuk bergerak ke kiri                   |\n");
   printf("\t|  e untuk save game                          |\n");
   printf("\t|  f untuk kembali ke menu                    |\n");
   printf("\t|=============================================|\n");
   printf("\t| anda memilih ?                              |\n");
   printf("\t|=============================================|\n");
   char pilih;
   getchar();
   scanf("%c", &pilih);
   return pilih;
}

int Run(int baris, int kolom, char **peta2d)
{
   char pilih = 0;
   do
   {
      int i;
      for (i = 0; i < baris; i++)
      {
         int j;
         for (j = 0; j < kolom; j++)
         {
            if (i == Data.perawatY && j == Data.perawatX)
            {
               printf("O ");
            }
            else if (i == Data.pasienY && j == Data.pasienX)
            {
               printf("^ ");
            }
            else
            {
               printf("%c ", peta2d[i][j]);
            }
         }
         printf("\n");
      }

      printf("\n");
      printf("|==========================================|\n");
      printf("| Perawat    - o                           |\n");
      printf("| Pasien     - ^                           |\n");
      printf("|==========================================|\n");
      printf("\n\t  |Posisi Y perawat dalam kolom       - %d \n", Data.perawatX + 1);
      printf("\t  |Posisi X perawat dalam baris       - %d \n", Data.perawatY + 1);
      printf("\t  |Posisi Y pasien dalam kolom        - %d \n", Data.pasienX + 1);
      printf("\t  |Posisi X pasien dalam baris        - %d \n", Data.pasienY + 1);
      pilih = MenuGame();
      switch (pilih)
      {
      case 'w':
         Data.perawatY--;
         break;
      case 'd':
         Data.perawatX++;
         break;
      case 's':
         Data.perawatY++;
         break;
      case 'a':
         Data.perawatX--;
         break;

      case 'e':
         saveGame();
         menu();
         break;

      case 'f':
         return 0;
         menu();
         break;

      default:
         break;
      }
      if (Data.perawatY == -1)
      {
         Data.perawatY = 0;
      }
      else if (Data.perawatY == baris)
      {
         Data.perawatY = baris - 1;
      }
      if (Data.perawatX == -1)
      {
         Data.perawatX = 0;
      }
      else if (Data.perawatX == kolom)
      {
         Data.perawatX = kolom - 1;
      }

      if (Data.perawatX == Data.pasienX && Data.perawatY == Data.pasienY)
      {

         int win1;
         printf("|===============|SELAMAT ANDA MENANG|===============|\n");
         printf("|   1. ke menu utama                                |\n");
         printf("|   2. Akhiri permainan                             |\n");
         printf("|   pilihan anda adalah ?                           |\n");
         printf("|===================================================|\n");
         scanf("%d", &win1);
         if (win1 == 1)
         {
            return menu();
         }
         else if (win1 == 2)
         {
            printf("Terimakasih Sudah Bermain\n");
            exit(0);
         }
         else
         {
            printf("Input yang benar\n");
         }

         getchar();
         pilih = 0;
      }
   } while (pilih != 'x');
   return pilih;
}

int gstart()
{
   int baris = 5;
   int kolom = 7;
   char **peta2d;
   printf("\tsilahkan masukkan jumlah baris yang diinginkan?");
   scanf("%d", &baris);
   printf("\tsilahkan masukkan jumlah kolom yang diinginkan?");
   scanf("%d", &kolom);
   peta2d = calloc(baris, sizeof(char *));
   if (peta2d == NULL)
   {
      printf("pembuatan peta gagal!\n");
      return -1;
   }
   int i;
   for (i = 0; i < baris; i++)
   {
      peta2d[i] = calloc(kolom, sizeof(int));
      if (peta2d[i] == NULL)
      {
         printf("pembuatan peta gagal!\n");
         return -1;
      }
   }
   for (i = 0; i < baris; i++)
   {
      int j;
      for (j = 0; j < kolom; j++)
      {
         peta2d[i][j] = '*';
      }
   }
   Data.perawatX = rand() % kolom;
   Data.perawatY = rand() % baris;
   do
   {
      Data.pasienX = rand() % kolom;
      Data.pasienY = rand() % baris;
   } while (Data.perawatX == Data.pasienY && Data.perawatY == Data.pasienY);
   Run(baris, kolom, peta2d);
   for (i = 0; i < baris; i++)
   {
      free(peta2d[i]);
      peta2d[i] = NULL;
   }
   free(peta2d);
   peta2d = NULL;
   return 0;
}

int main()
{
   srand(time(NULL));
   while (1)
   {
      int i = menu();
      if (i == 1)
      {
         gstart();
      }
      else if (i == 2)
      {
         printf("\t|=========== | ATURAN PERMAINAN | ============|\n");
         printf("\t|  w untuk bergerak ke atas                   |\n");
         printf("\t|  d untuk bergerak ke kanan                  |\n");
         printf("\t|  s untuk bergerak ke bawah                  |\n");
         printf("\t|  a untuk bergerak ke kiri                   |\n");
         printf("\t|  e untuk permainan selesai                  |\n");
         printf("\t|  f untuk kembali ke menu                    |\n");
         printf("\t|  g untuk save game                          |\n");
         printf("\t|=============================================|\n");

         printf("\tsilahkan enter untuk lanjut game\n");
         getchar();
         getchar();
      }
      else if (i == 3)
      {
         loadGame();
      }
      else if (i == 4)
      {
         if (keluar() == 'y')
         {
            break;
         }
      }
   }
   return 0;
}