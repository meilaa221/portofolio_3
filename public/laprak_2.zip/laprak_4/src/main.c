//PROGRAM KASIR APOTEK UNISA
//MENGGUNAKAN PERCABANGAN GABUNGAN IF-ELSE & SWITCH-CASE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
    char nama;
    int harga, obat_bebas, o1, o2, o3, obat_narkotika, o4, o5, o6, obat_keras, o7, o8, o9, jumlah_item;
    float total_obatbebas, total_obatnarkotika, total_obatkeras, total_bayar, tunai, kembalian;
    
    printf("\t======================================================\n");
    printf("\t||                KASIR APOTIK UNISA                ||\n");
    printf("\t||             MENYEDIAKAN BERBAGAI OBAT            ||\n");
    printf("\t======================================================\n\n");

    printf("\t------------------------------------------------------\n\n");


    printf("-_-       Daftar Obat     -_- \n");
    printf("------------------------------\n");
    printf("1. paracetamol     = 10000    \n");
    printf("2. ibuprofen       = 12000    \n");
    printf("3. antasida        = 15000    \n");
    printf("4. morfin          = 200000   \n");
    printf("5. tramadol        = 500000   \n");
    printf("6. diazepam        = 700000   \n");
    printf("7. alprazolam      = 300000   \n");
    printf("8. ethambutol      = 500000   \n");
    printf("9. antibiotik      = 70000    \n");

    start1:
        printf("\nNama Pelanggan : ");
        scanf("%s", &nama);
        printf("Pemesanan obat bebas (1-3) : ");
        scanf("%d", &obat_bebas);
        printf("-----------------------\n");

        switch (obat_bebas){
        case 1 :
            o1= 10000;
            printf("paracetamol : Rp.%d\n", o1);
            printf("Jumlah Pesanan : "); scanf("%d", &jumlah_item);
            total_obatbebas += o1*jumlah_item;
            printf("total_obatbebas += Rp. %d\n\n", o1*jumlah_item);
            break;

         case 2 :
            o2= 12000;
            printf("ibuprofen : Rp.%d\n", o2);
            printf("Jumlah item : ");scanf("%d", &jumlah_item);
            total_obatbebas += o2*jumlah_item;
            printf("total_obatbebas += Rp. %d\n\n",o2*jumlah_item);
            break;
         case 3 :
            o3= 15000;
            printf("antasida : Rp.%d\n", o3);
            printf("Jumlah item : ");scanf("%d", &jumlah_item);
            total_obatbebas += o3*jumlah_item;
            printf("total_obatbebas += Rp. %d\n\n",o3*jumlah_item);
            break;
        default:
            printf("Maaf Obat belum tersedia!\n", obat_bebas);
            printf("Silahkan lakukan pemesanan ulang!\n");
        }      
     start2:
        printf("Pemesanan obat narkotika (4-6) : ");
        scanf("%d", &obat_narkotika);
        printf("--------------------------------\n");

        switch (obat_narkotika)
        {
        case 4 :
            o4 = 200000;
            printf("morfin : Rp.%d\n", o4);
            printf("Jumlah item : ");scanf("%d", &jumlah_item);
            total_obatnarkotika += o4*jumlah_item;
            printf("total_obatnarkotika += Rp. %d\n\n",o4*jumlah_item);
            break;
        case 5 :
            o5 = 500000;
            printf("tramadol : Rp.%d\n", o5);
            printf("Jumlah item : ");scanf("%d", &jumlah_item);
            total_obatnarkotika += o5*jumlah_item;
            printf("total_obatnarkotika += Rp. %d\n\n",o5*jumlah_item);
            break;
        case 6 :
            o6 = 700000;
            printf("diazepam : Rp.%d\n", o6);
            printf("Jumlah item : ");scanf("%d", &jumlah_item);
            total_obatnarkotika += o6*jumlah_item;
            printf("total_obatnarkotika += Rp. %d\n\n",o6*jumlah_item);
            break;
        default:
            printf("Maaf Obat belum tersedia!\n", obat_narkotika);
            printf("Silahkan lakukan pemesanan ulang!\n");
        }
     start3:
        printf("Pemesanan obat keras (7-9) : ");
        scanf("%d", &obat_keras);

        switch (obat_keras)
        {
        case 7 :
            o7 = 300000;
            printf("alprazolam : Rp.%d\n", o7);
            printf("Jumlah item : ");scanf("%d", &jumlah_item);
            total_obatkeras += o7*jumlah_item;
            printf("total_obatkeras += Rp. %d\n\n",o7*jumlah_item);
            break;
        case 8 :
            o8 = 500000;
            printf("ethambutol : Rp.%d\n", o8);
            printf("Jumlah item : ");scanf("%d", &jumlah_item);
            total_obatkeras += o8*jumlah_item;
            printf("total_obatkeras += Rp. %d\n\n",o8*jumlah_item);
            break;
        case 9 :
            o9 = 70000;
            printf("antibiotik : Rp.%d\n", o9);
            printf("Jumlah item : ");scanf("%d", &jumlah_item);
            total_obatkeras += o9*jumlah_item;
            printf("total_obatkeras += Rp. %d\n\n",o9*jumlah_item);
            break;

        default:
            printf("Maaf Obat belum tersedia!\n", obat_keras);
            printf("Silahkan lakukan pemesanan ulang!\n");
        }

        total_bayar = total_obatbebas + total_obatnarkotika + total_obatkeras;
        printf("total_bayar = Rp. %f\n", total_bayar);

    start4:
        printf("Bayar Tunai = Rp.");
        scanf("%f", &tunai);

        if(tunai > total_bayar)
        {
            kembalian = tunai - total_bayar;
            printf("Kembalian = Rp. %f\n", kembalian);
            printf("Terimakasih Atas Kunjungannya");
        }
        else
        {
            printf("Maaf Uang Tidak Cukup!\n");
            goto start4;
        }

return 0;
}