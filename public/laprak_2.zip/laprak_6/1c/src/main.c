#include <stdio.h>

int main()
{
    int n = 6; //jumlah baris
    int i, j;

    for (i = 1; i <= n; i++) {
        // Mencetak angka dari 1 hingga (n- i + 1)
        for (j = 1; j<= n - i + 1; j++){
            printf("%d ", j);
        }

        //Mencetak spasi
        for (j = 0; j< 2 * (i - 1); j++){
            printf("  ");
        }

        //Mencetak angka dari (n - i + 1) ke 1 dalam urutan
        for (j = n - i + 1; j >= 1; j--) {
            printf("%d ", j);
        }

        //pindah ke baris berikutnya
        printf("\n");
    }

    return 0;
}