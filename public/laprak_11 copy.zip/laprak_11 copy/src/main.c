#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum {
    pemeriksaan,
    pembelianobat
} pilihan;

typedef struct {
    char pasien[50];
    pilihan pilihan;
} Data;

typedef union {
    char *umur;
} jenisperawatan;

void datapasiendentalcare(Data *data, const char *pasien, pilihan jenis) {
    snprintf(data->pasien, sizeof(data->pasien), "%s", pasien);
    data->pilihan = jenis;
}

void datadetailpasiendentalcare(jenisperawatan *detail, const char *umur) {
    detail->umur = malloc(strlen(umur) + 1);
    strcpy(detail->umur, umur);
}

void hapusJenisPerawatan(jenisperawatan *detail) {
    free(detail->umur);
}

void cetakData(Data *data, jenisperawatan *detail) {
    printf("\nInformasi kelas pasien::\n");
    printf("pasien : %s\n", data->pasien);
    printf("alamat: %s\n", data->pilihan == pemeriksaan ? "pemeriksaan" : "pembelianobat");
    printf("umur : %s\n", detail->umur);
}
int main() {

int choice;
int  i = 1, pilihan, gopay, ovo, dana, mbanking, cash,bank, biaya, kembalian, total, kurang;
char bayar [50];

printf("       SISTEM DENTAL CARE       \n");
printf("     RUMAH SAKIT UNISAYOGYA     \n");
printf("--------------------------------\n");
printf("--------------------------------\n");

printf("pilih menu yang ingin dilakukan:\n");
printf("1. data pasien\n");
printf("2. jenis pemeriksaan\n");
printf("3. pemberian obat\n");
printf("4. pembayaran\n");
printf("pilihan anda: ");
scanf("%d", &choice);

switch(choice) {
    case 1: {
    FILE* fp = fopen("dentalcare.csv", "a+");
    char nama[50], alamat[50], riwayat_kesehatan[50];
    int tanggal_lahir;
    if (!fp) {
    printf("file tidak dapat dibuka\n");
    return 0;
    }
    printf("Masukkan nama anda: ");
    scanf("%s", &nama);
    printf("tanggal lahir: ");
    scanf("%d", &tanggal_lahir);
    printf("masukkan alamat anda: ");
    scanf("%s", &alamat);
    printf("riwayat kesehatan: ");
    scanf("%s", &riwayat_kesehatan);

    fprintf(fp, "%s, %d, %s, %s\n", nama, tanggal_lahir, alamat, riwayat_kesehatan);
    printf("\nData telah disimpan");
    fclose(fp);

    printf("\n\n\n\n");

    FILE* fpp = fopen("dentalcare.csv", "r+");
    if (!fpp){
    printf("file tidak dapat dibuka\n");
    return 0;
    }else {
    char buffer[1024];
    int row = 0;
    int column = 0;
    while (fgets(buffer, 1024, fpp))
    {
        column = 0;
        row++;

        if (row == 0)
            continue;
        char* value = strtok(buffer, ", ");

        while (value) {
            if (column == 0) {
                printf("nama :");
            }
            if (column == 1) {
                printf("\ttanggal lahir :");
            }
            if (column == 2) {
                printf("\talamat :");
            }
            if (column == 3) {
                printf("\triwayat kesehatan :");
            }
            printf("%s", value);
            value = strtok(NULL, ", ");
            column++;}
    }fclose(fpp);
}
return 0;
}
    case 2: {
    
    FILE* fp = fopen("dentalcare.csv", "a+");
    if (!fp) {
    printf("file tidak dapat dibuka\n");
    return 0;
    }
    
    int pilihan;
                 printf("Masukkan Jenis Pemeriksaan:\n ");
                 printf("1.karang gigi\n");
                 printf("2.cabut gigi\n");
                 printf("3.tambal gigi\n");
                 scanf(" %i", &pilihan);
            if (pilihan == 1)
                {
    
                    printf ("pemeriksaan karang gigi\n");
                    printf ("dokter susi  = 50000\n ");
                }
                    
                    else if ( pilihan == 2)
                {
                    
                    printf ("pemeriksaan cabut gigi\n");
                    printf ("dokter puji = 75000\n ");
                }
                    else if ( pilihan == 3)
                {
                    
                    printf ("pemeriksaan tambal gigi\n");
                    printf ("dokter sari = 300000\n ");
                }
            else   
            {

                    printf ("Jenis Pemerriksaan yg anda pilih tidak ada");
            }
                 printf("TERIMAKASIH SUDAH MENDAFTAR SILAHKAN MENUNGGU PANGGILAN\n");

        break;

    FILE* fpp = fopen("dentalcare.csv", "r+");
    if (!fpp)
    {
    printf("file tidak dapat dibuka\n");
    return 0;
    }
    else
    {
    char line[100];
    char *token;
    while (fgets(line, 100, fpp)) 
    {
    token = strtok(line, ",");
    printf("%s\n", token);
    }
    }

    fclose(fpp);

return 0;
}
    case 3: {
        FILE* fp = fopen("dentalcare.csv", "a+");
    if (!fp) {
    printf("file tidak dapat dibuka\n");
    return 0;
    }
    
    int pilihan;
                 printf("pemberian obat:\n ");
                 printf("1. asam mafenamat\n");
                 printf("2. ibuprpfen\n");
                 printf("3. paracetamol\n");
                 printf("4. Naproxen\n");
                 printf("5. diklofenak\n");
                 scanf(" %i", &pilihan);
                if (pilihan == 1)
                {
    
                    printf ("pemberian obat asam mafenamat\n");
                    printf ("harga  = 50000\n ");
                }
                    
                    else if ( pilihan == 2)
                {
                    
                    printf ("pemberian obat ibuprofen\n");
                    printf ("harga = 75000\n ");
                }
                    else if ( pilihan == 3)
                {
                    
                    printf ("pemberian obat paracetamol\n");
                    printf ("harga = 300000\n ");
                }
                if (pilihan == 4)
                {
    
                    printf ("pemberian obat naproxen\n");
                    printf ("harga  = 50000\n ");
                }
                    
                    else if ( pilihan == 5)
                {
                    
                    printf ("pemberian obat diklovenak\n");
                    printf ("harga = 75000\n ");
                }

            else   
            {

                    printf ("obat yang anda masukkan sedang habis");
            }
                 printf("TERIMAKASIH SUDAH MENDAFTAR SILAHKAN MENUNGGU PANGGILAN\n");

        break;

    FILE* fpp = fopen("dentalcare.csv", "r+");
    if (!fpp)
    {
    printf("file tidak dapat dibuka\n");
    return 0;
    }
    else
    {
    char line[100];
    char *token;
    while (fgets(line, 100, fpp)) 
    {
    token = strtok(line, ",");
    printf("%s\n", token);
    }
    }

    fclose(fpp);

return 0;
    }
    case 4: {
    FILE* fp = fopen("dentalcare.csv", "a+");
    int pilihan;
    char nama_obat[50], manfaat[50], jumlah[50], tanggal_pembelian[50];
    if (!fp) {
    printf("file tidak dapat dibuka\n");
    return 0;
    }
            printf("pembayaran\n");
            printf("1. cash\n");
            printf("2. qris\n");
            printf("input pilihan : ");
            scanf("%i", &pilihan);
            if (pilihan == 1)
            {
                printf("\ninput nilai uang cash :\n ");
                scanf("%i", &cash);
                printf("\ninput biaya pemeriksaan (minta rincian biaya di bagian administrasi) :\n ");
                scanf("%i", &biaya);

               
                if ( cash > biaya) {
                kembalian = cash - biaya;

                printf ("\nkembalian anda: %i\n", kembalian ); 
                }

                else 
                {
                kurang = biaya - cash;
                printf ("\nmaaf uang anda tidak cukup,\n: %i", kurang);
                printf ("\nPembayaran Gagal");
                break;
                }
                
            }
            else if (pilihan == 2)
            {
                
                printf("\n------------------------------ ");
                printf("\n----------Via----------------- ");
                printf("\n------------------------------ ");
                printf("\n1.gopay (pajak 1500)");
                printf("\n2.ovo (pajak 1000)");
                printf("\n3.dana(pajak 2000)");
                printf("\n4.mbanking (pajak 2500)");
                printf("\npilih (1/2/3/4)");
                scanf("%i", &pilihan);
                  if (pilihan == 1)
            {
                printf("\ninput biaya pemeriksaan:\n ");
                scanf("%i", &gopay);
                total = gopay - 1500;
                printf ("\nbiaya anda setelah dikurangi pajak : %i\n", total ); 
            
            }

                else if (pilihan == 2)
            {
                 printf("\ninput biaya pemeriksaan:\n ");
                scanf("%i", &ovo);
                total = ovo - 1000;
                printf ("\nbiaya anda setelah dikurangi pajak : %i\n", total ); 
            }
                 else if (pilihan == 3)
            {
                printf("\ninput biaya pemeriksaan:\n ");
                scanf("%i", &dana);
                total = dana - 2000;
                printf ("\nbiaya anda setelah dikurangi pajak : %i\n", total ); 
            }
                else if (pilihan == 4)
            {
                 printf("\ninput biaya pemeriksaan:\n ");
                scanf("%i", &mbanking);
                total = mbanking - 2000;
                printf ("\nbiaya anda setelah dikurangi pajak : %i\n", total ); 

            }
            }
            if (pilihan == 13)
            {
                printf("\nmasukkan rekening anda :\n ");
                scanf("%i", &bank);
                printf("\ninput biaya pemeriksaan (minta rincian biaya di bagian administrasi) :\n ");
                scanf("%i", &biaya);

               
                if ( bank > biaya) {
                kembalian = bank - biaya;

                printf ("\nkembalian anda: %i\n", kembalian ); 
                }

                else 
                {
                kurang = bank - cash;
                printf ("\nmaaf uang anda tidak cukup,\n: %i", kurang);
                printf ("\nPembayaran Gagal");
                break;
                }
                
            }
            {
                printf("\nsalah input \n");
            }  
                printf("\nTERIMAKASIH PEMBAYARAN ANDA BERHASIL\n");

    FILE* fpp = fopen("dentalcare.csv", "r+");
    if (!fpp)
    {
    printf("file tidak dapat dibuka\n");
    return 0;
    }
    else
    {
    char line[10000];
    char *token;
    while (fgets(line, 10000, fpp)) 
    {
    token = strtok(line, ",");
    printf("%s\n", token);
    }
    }

    fclose(fpp);

return 0;
    }
    case 5: {
        printf("\nterimakasih sudah mengunjungi web kami");
        return 0;
    }
}
}