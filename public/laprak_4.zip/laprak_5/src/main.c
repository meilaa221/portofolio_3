#include <stdio.h>
#include <math.h>

int main() {
    int pilih, pilihan;
    double hasil, jam, bayar_jantung, bayar_paru, bayar_orthopedi, bayar_umum;

    printf("Pilih Poliklinik Yang Di Inginkan\n");
    printf("1. poli jantung\n");
    printf("2. Poli Paru-Paru\n");
    printf("3. Poli Orthopedi\n");
    printf("4. Poli Umum\n");
    printf("Pilih Poliklinik : ");
    scanf("%d", &pilih);

    switch (pilih) {
        case 1:
            printf("\nPilih Perawatan jantung\n");
            printf("1. elektrokardiografi\n");
            printf("2. ekokardiografi\n");
            printf("Input Pilihan : ");
            scanf("%i", &pilihan);
            if (pilihan == 1)
            {
                printf("\ninput lama pemeriksaan:  ");
                scanf("%lf", &jam);
                hasil = 200000 * jam;
                printf("\nharga elektrokardiografi: %lf\n", hasil);
            }
            else if (pilihan == 2)
            {
                printf("\ninput lama pemeriksaan: ");
                scanf("%lf", &jam);
                hasil = 300000 * jam;
                printf("\nharga ekokardiografi: %lf\n", hasil);    
            }
            else
            {
                printf("\nSalah input! \n");
            }
        break;
        case 2:
           printf("\nPoli Paru-Paru\n");
           printf("1. tes fungsi paru-paru\n");
           printf("2. tes pemindaian\n");
           printf("Input Pilihan : ");
           scanf("%i", &pilihan);
           if (pilihan == 1)
            {
                printf("\ninput lama pemeriksaan:  ");
                scanf("%lf", &jam);
                hasil = 70000 * jam;
                printf("\nharga tes fungsi paru-paru: %lf\n", hasil);
            }
            else if (pilihan == 2)
            {
                printf("\ninput lama pemeriksaan:  ");
                scanf("%lf", &jam);
                hasil = 80000 * jam;
                printf("\nharga tes pemindaian: %lf\n", hasil);
            }
            else
            {
                printf("salah input! \n");
            }
        break;
        case 3:
            printf("\nPoli Orthopedi\n");
            printf("1. perawatan patah tulang\n");
            printf("2. CT SCAN\n");
            printf("input pilihan : ");
            scanf("%i", &pilihan);
            if (pilihan == 1)
            {
                printf("\ninput perawatan patah tulang: ");
                scanf("%lf", &jam);
                hasil =  90000 * jam;
                printf("\nharga perawatan patah tulang: %lf\n", hasil);
            }
            else if (pilihan == 2)
            {
                printf("\ninput CT SCAN\n: ");
                scanf("%lf", &jam);
                hasil = 100000* jam;
                printf("\nharga CT SCAN: %lf\n", hasil);
            }
            else
            {
                printf("Salah input! \n");
            }
        break;
        case 4:
           printf("\nPoli Umum\n");
           printf("1. pemeriksaan kesehatan\n");
           printf("2. pengobatan \n");
           printf("Input Pilihan : ");
           scanf("%i", &pilihan);
           if (pilihan == 1)
            {
                printf("\ninput lama pemeriksaan:  ");
                scanf("%lf", &jam);
                hasil = 30000 * jam;
                printf("\nharga pemeriksaan kesehatan: %lf\n", hasil);
            }
            else if (pilihan == 2)
            {
                printf("\ninput lama pemeriksaan:  ");
                scanf("%lf", &jam);
                hasil = 40000 * jam;
                printf("\nharga pengobatan: %lf\n", hasil);
            }
            else
            {
                printf("salah input! \n");
            }
        default:
            printf("pilihan salah!\n");
        break;
    }

    return 0;
}
