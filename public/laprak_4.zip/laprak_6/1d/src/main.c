#include <stdio.h>

int main() {
    
    int i;
    
    //perulangan for
    printf("=== Perulangan for ===\n");
    for (i = 1; i <= 15; i++) {
        
        printf("Data diri ke-%d\n", i);
        printf("Nama: Dian Gita Meilani\n ");
        printf("prodi: Teknologi Informasi\n ");
        printf("fakultas: fakultas sains dan teknologi\n ");
        printf("alamat: ngawi\n ");
    }

    //perulangan while
    printf("=== Perulangan while ===\n");
    i = 1;
    while (i <= 15){
        printf("Data diri ke-%d\n", i);
        printf("Nama: Dian Gita Meilani\n ");
        printf("prodi: Teknologi Informasi\n ");
        printf("fakultas: fakultas sains dan teknologi\n ");
        printf("alamat: ngawi\n ");

        i++;
    }

    //perulangan do-while
    printf("\n=== Perulangan do-while ===\n");
    i = 1;
    do {
        printf("Data diri ke-%d\n", i);
        printf("Nama: Dian Gita Meilani\n ");
        printf("prodi: Teknologi Informasi\n ");
        printf("fakultas: fakultas sains dan teknologi\n ");
        printf("alamat: ngawi\n ");

        i++;

    } while (i <= 15);

    return 0;
}
